San Donato / Campidoglio pilot. GeoPackage EPSG:32632.
Apartment interior geometry and PODs are not available. APE point geometry is an entrance proxy only.
Multi-subalterno APE totals are not duplicated per identifier. Census allocations and energy scenarios are not measurements.
Read DATA_REVIEW.md for dates, source links, attribution and material limitations.
