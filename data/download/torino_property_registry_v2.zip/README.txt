Local v2 public-source register. Properties/groups and certificates are different grains, not a complete apartment census.
No apartment interior geometry, PODs or measured consumption. Multi-subalterno certificate totals are not duplicated.
Relationship proposals are unreviewed source-derived candidates. The local review ledger and all review notes are excluded.
Blank fields mean unknown/not reported, never zero. Roof evidence is not a surveyed LoD2/2.5 dataset.
Original-provider attribution and source dates are retained in source-audit.json and certificate source URLs.
